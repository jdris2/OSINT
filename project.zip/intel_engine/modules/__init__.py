"""Intel modules package."""

from .research_abn_lookup import ResearchABNLookup

__all__ = ["ResearchABNLookup"]
