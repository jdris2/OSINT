"""Module: Research_Shared_Breaches_HaveIBeenPwned

This module simulates checking a subject's email addresses against the HaveIBeenPwned (HIBP) data breach database.
It determines if any of the subject's emails have appeared in known data breaches and records the types of data exposed
(e.g., passwords, locations, usernames). The results are stored in the profile's 'risk' section as red flags, following
the system's schema. This is a deterministic mock for testing and does not perform real network calls.

Data Source: Simulated HaveIBeenPwned (https://haveibeenpwned.com/)
Purpose: Identify and record potential data breach exposures for a subject based on their email addresses.
"""

import logging
from hashlib import sha256
from typing import Any, Dict, List, Optional

from intel_engine.core.module_base import IntelModuleBase

class Research_Shared_Breaches_HaveIBeenPwned(IntelModuleBase):
    """Check if subject's emails appear in known data breaches and record what was leaked."""

    MODULE_NAME = "Research_Shared_Breaches_HaveIBeenPwned"
    PROFILE_SCHEMA = {
        "type": "object",
        "properties": {
            "contact": {
                "type": "object",
                "properties": {
                    "emails": {
                        "type": "array",
                        "items": {"type": "string", "format": "email"},
                    }
                },
            },
            "risk": {
                "type": "object",
                "properties": {
                    "red_flags": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "category": {"type": "string"},
                                "description": {"type": "string"},
                                "severity": {
                                    "type": "string",
                                    "enum": ["low", "medium", "high", "critical"],
                                },
                            },
                        },
                    }
                },
            },
        },
        "required": [],
    }

    OUTPUT_SCHEMA = {
        "type": "object",
        "properties": {
            "risk": {
                "type": "object",
                "properties": {
                    "red_flags": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "category": {"type": "string"},
                                "description": {"type": "string"},
                                "severity": {
                                    "type": "string",
                                    "enum": ["low", "medium", "high", "critical"],
                                },
                            },
                        },
                    }
                },
            }
        },
        "required": ["risk"],
    }

    # Simulated breach types for deterministic mock
    _BREACH_TYPES = [
        ("Passwords", "Password(s) exposed", "high"),
        ("Usernames", "Username(s) exposed", "medium"),
        ("Locations", "Location data exposed", "medium"),
        ("PhoneNumbers", "Phone number(s) exposed", "medium"),
        ("DatesOfBirth", "Date of birth exposed", "medium"),
        ("Emails", "Email address exposed", "low"),
    ]

    def __init__(self, logger: Optional[logging.Logger] = None) -> None:
        super().__init__(
            module_name=self.MODULE_NAME,
            profile_schema=self.PROFILE_SCHEMA,
            output_schema=self.OUTPUT_SCHEMA,
            logger=logger,
        )

    def validate_input(self) -> None:
        """Ensure at least one email is present for breach checking."""
        super().validate_input()
        profile = self._current_profile or {}
        emails = (
            profile.get("contact", {}).get("emails")
            if profile.get("contact")
            else []
        )
        if not emails or not isinstance(emails, list) or not any(emails):
            raise ValueError(
                "Research_Shared_Breaches_HaveIBeenPwned requires at least one contact.email."
            )

    def _execute_impl(self, profile: Dict[str, Any]) -> Dict[str, Any]:
        """Simulate breach checks and update the risk section with red flags."""
        emails = profile.get("contact", {}).get("emails", [])
        red_flags: List[Dict[str, Any]] = []

        for email in emails:
            breaches = self._mock_breach_lookup(email)
            for breach in breaches:
                red_flags.append({
                    "category": "data_breach",
                    "description": f"Email '{email}': {breach['description']}",
                    "severity": breach["severity"],
                })

        # Update the profile's risk.red_flags in place
        risk_section = profile.setdefault("risk", {})
        risk_section.setdefault("red_flags", [])
        risk_section["red_flags"].extend(red_flags)

        # Return only the risk section as output
        return {"risk": {"red_flags": risk_section["red_flags"]}}

    def _mock_breach_lookup(self, email: str) -> List[Dict[str, str]]:
        """
        Deterministically simulate breach results for a given email.

        The hash of the email determines which breach types are 'exposed'.
        """
        digest = sha256(email.encode("utf-8")).hexdigest()
        # Use the first 6 hex digits to select breach types
        breach_flags = [int(d, 16) % 2 == 0 for d in digest[:6]]
        breaches = []
        for flag, (field, description, severity) in zip(breach_flags, self._BREACH_TYPES):
            if flag:
                breaches.append({
                    "field": field,
                    "description": description,
                    "severity": severity,
                })
        return breaches
