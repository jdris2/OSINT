# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Automation_SpiderFoot

### Description
Automated OSINT scanning across hundreds of data sources to build a comprehensive intelligence profile.

### Inputs
- target
- scan_profile
- module_selection

### Outputs
- entities
- relationships
- indicators

### Execution_Steps
1. Accept target
   A. Domain
   B. IP
   C. Username
2. Select scan profile
   A. Light
   B. Standard
   C. Deep
3. Initialize SpiderFoot
   A. Load config
   B. Enable modules
   C. Set limits
4. Run scan
   A. Parallel queries
   B. Rate control
   C. Error handling
5. Collect entities
   A. Emails
   B. Domains
   C. IPs
6. Build relationships
   A. Entity linking
   B. Confidence scoring
   C. Graph mapping
7. Normalize data
   A. Schema mapping
   B. Deduplication
   C. Validation
8. Output results
   A. JSON
   B. Graph
   C. Report

### Dependencies
- SpiderFoot
- Python

### Notes
Best used as a full-spectrum reconnaissance module.
