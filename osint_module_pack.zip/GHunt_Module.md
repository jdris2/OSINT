# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Account_Google_Intel

### Description
Investigates Google accounts and related services.

### Inputs
- email

### Outputs
- services
- profile_data

### Execution_Steps
1. Accept email
   A. Validate
   B. Normalize
   C. Store
2. Authenticate GHunt
   A. Tokens
   B. Session
   C. Config
3. Query services
   A. YouTube
   B. Maps
   C. Photos
4. Extract metadata
   A. Profile
   B. IDs
   C. Activity
5. Correlate services
   A. Cross-links
   B. Confidence
   C. Tags
6. Normalize output
   A. Schema
   B. Clean
   C. Validate
7. Store findings
   A. Cache
   B. DB
   C. Backup
8. Export results
   A. JSON
   B. Entity
   C. Report

### Dependencies
- GHunt
- Python

### Notes
Email-based identity enrichment.
