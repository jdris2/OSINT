# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Social_Twitter_Intelligence

### Description
Collects tweets, followers, networks, and timelines without API access.

### Inputs
- username
- keywords
- date_range

### Outputs
- tweets
- networks
- metrics

### Execution_Steps
1. Accept parameters
   A. Username
   B. Keywords
   C. Dates
2. Configure Twint
   A. Filters
   B. Limits
   C. Language
3. Execute scrape
   A. Timeline
   B. Search
   C. Network
4. Parse tweets
   A. Text
   B. Hashtags
   C. Mentions
5. Extract networks
   A. Followers
   B. Following
   C. Interactions
6. Compute metrics
   A. Frequency
   B. Reach
   C. Sentiment
7. Normalize data
   A. Schema map
   B. Clean
   C. Validate
8. Output intelligence
   A. JSON
   B. Graph
   C. Report

### Dependencies
- Twint
- Python

### Notes
Supports social behavior analysis.
