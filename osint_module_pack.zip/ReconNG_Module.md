# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Framework_ReconNG

### Description
Framework-driven reconnaissance using modular OSINT scripts.

### Inputs
- workspace
- target
- modules

### Outputs
- findings
- logs

### Execution_Steps
1. Create workspace
   A. Name workspace
   B. Init DB
   C. Set context
2. Load target
   A. Domain
   B. Company
   C. Contact
3. Select modules
   A. Whois
   B. Breach
   C. Contacts
4. Execute modules
   A. Sequential run
   B. Error capture
   C. Logging
5. Parse output
   A. Tables
   B. Records
   C. Metadata
6. Correlate data
   A. Cross-module links
   B. Scoring
   C. Flag anomalies
7. Store results
   A. Database
   B. Cache
   C. Backup
8. Export report
   A. JSON
   B. CSV
   C. Engine ingest

### Dependencies
- Recon-ng
- Python

### Notes
Integrates cleanly with structured workflows.
