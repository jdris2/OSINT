# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Identity_Username_Search

### Description
Searches for usernames across hundreds of platforms.

### Inputs
- username

### Outputs
- platform_hits
- profile_links

### Execution_Steps
1. Accept username
   A. Normalize
   B. Validate
   C. Store
2. Load platform list
   A. Social
   B. Forums
   C. Services
3. Execute checks
   A. HTTP requests
   B. Status parsing
   C. Timeout handling
4. Identify hits
   A. Status code
   B. Content match
   C. Confidence
5. Collect URLs
   A. Profile links
   B. Avatars
   C. Metadata
6. Deduplicate
   A. Hashing
   B. Canonical URLs
   C. Merge
7. Score relevance
   A. Activity
   B. Completeness
   C. Signals
8. Output results
   A. JSON
   B. Entity creation
   C. Report

### Dependencies
- Sherlock
- Python

### Notes
Used for identity expansion.
