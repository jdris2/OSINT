# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Web_Crawling_Photon

### Description
Crawls websites to extract URLs, emails, and endpoints.

### Inputs
- base_url
- depth

### Outputs
- urls
- emails
- endpoints

### Execution_Steps
1. Accept URL
   A. Validate
   B. Normalize
   C. Store
2. Configure crawl
   A. Depth
   B. Threads
   C. Limits
3. Start crawl
   A. Fetch pages
   B. Parse HTML
   C. Queue links
4. Extract URLs
   A. Internal
   B. External
   C. Assets
5. Extract emails
   A. Regex
   B. Validate
   C. Tag
6. Identify endpoints
   A. APIs
   B. Params
   C. Forms
7. Deduplicate
   A. Hash
   B. Canonical
   C. Merge
8. Output results
   A. JSON
   B. Map
   C. Report

### Dependencies
- Photon
- Python

### Notes
Supports attack surface mapping.
