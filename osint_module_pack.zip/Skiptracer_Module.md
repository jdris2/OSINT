# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Enrichment_Skiptracer

### Description
Aggregates enrichment data for emails, phones, and usernames.

### Inputs
- identifier

### Outputs
- enriched_profile

### Execution_Steps
1. Accept identifier
   A. Email
   B. Phone
   C. Username
2. Normalize input
   A. Format
   B. Validate
   C. Store
3. Query sources
   A. Breaches
   B. Social
   C. Public records
4. Collect signals
   A. Accounts
   B. Locations
   C. Associations
5. Correlate data
   A. Cross-source
   B. Confidence
   C. Tags
6. Score profile
   A. Completeness
   B. Freshness
   C. Risk
7. Normalize output
   A. Schema
   B. Clean
   C. Validate
8. Export profile
   A. JSON
   B. Entity
   C. Report

### Dependencies
- Skiptracer
- Python

### Notes
Used for deep identity enrichment.
