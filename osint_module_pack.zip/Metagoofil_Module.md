# PI INTEL SYSTEM – MODULE GENERATION PROMPT PACK (WITH TEMPLATE ENFORCEMENT)

---

### Module_Name
Research_Metadata_Document_Extraction

### Description
Extracts metadata from public documents.

### Inputs
- domain
- file_types

### Outputs
- metadata_records

### Execution_Steps
1. Accept domain
   A. Validate
   B. Normalize
   C. Store
2. Select file types
   A. PDF
   B. DOCX
   C. XLS
3. Search documents
   A. Engines
   B. Queries
   C. Collect URLs
4. Download files
   A. Validate
   B. Store
   C. Hash
5. Extract metadata
   A. Authors
   B. Software
   C. Dates
6. Correlate data
   A. Names
   B. Emails
   C. Systems
7. Normalize records
   A. Schema
   B. Clean
   C. Validate
8. Output results
   A. JSON
   B. Entities
   C. Report

### Dependencies
- Metagoofil
- Python

### Notes
Useful for attribution discovery.
